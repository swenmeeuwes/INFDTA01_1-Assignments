# INFDTA01_1-Assignments
Assignments for the course "INFDTA01_1"
Swen Meeuwes
